**To delete a flow log**

This example deletes flow log ``fl-1a2b3c4d``.

Command::

  aws ec2 delete-flow-logs --flow-log-id fl-1a2b3c4d

Output::

  {
    "Unsuccessful": []
  }